export const SET_CURRENT_USER = 'SET_CURRENT_USER'
export const GET_PETS = 'GET_PETS'
export const ADOPT_PET = 'ADOPT_PET'
export const GET_PROFILE = 'GET_PROFILE'
